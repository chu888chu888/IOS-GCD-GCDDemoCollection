//
//  MSWeakTimer_SampleProjectTests.h
//  MSWeakTimer-SampleProjectTests
//
//  Created by Javier Soto on 2/12/13.
//  Copyright (c) 2013 MindSnacks. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface MSWeakTimer_SampleProjectTests : SenTestCase

@end
