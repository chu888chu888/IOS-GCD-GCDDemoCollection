//
//  MSWeakTimer_SampleProjectTests.m
//  MSWeakTimer-SampleProjectTests
//
//  Created by Javier Soto on 2/12/13.
//  Copyright (c) 2013 MindSnacks. All rights reserved.
//

#import "MSWeakTimer_SampleProjectTests.h"

@implementation MSWeakTimer_SampleProjectTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in MSWeakTimer-SampleProjectTests");
}

@end
