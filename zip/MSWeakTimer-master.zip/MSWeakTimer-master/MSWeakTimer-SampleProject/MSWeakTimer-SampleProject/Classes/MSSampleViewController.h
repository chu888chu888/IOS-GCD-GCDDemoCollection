//
//  MSSampleViewController.h
//  MSWeakTimer-SampleProject
//
//  Created by Javier Soto on 2/12/13.
//  Copyright (c) 2013 MindSnacks. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MSSampleViewController : UIViewController

@end
