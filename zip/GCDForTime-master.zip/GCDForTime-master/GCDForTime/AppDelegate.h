//
//  AppDelegate.h
//  GCDForTime
//
//  Created by WangZeKeJi on 14-6-7.
//  Copyright (c) 2014年 ___ChengPeng___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
